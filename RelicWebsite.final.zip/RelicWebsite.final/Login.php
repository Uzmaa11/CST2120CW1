<?php
//Including Common php as it contains the header,navigation and footer which is common for all the pages
include('common.php');
//outputHeader function is called,it displays the Header which is common to all pages
outputHeader();

?>
<!--The pics class is called-->
<div class="pics">
    <!--The icons and text is styled inline-block-->
    <i class="fas fa-grin-beam" style="font-size:48px;color:red;display:inline-block;margin-left:250px;"></i>
    <h6 id="signin"><b> HELLO !</b></h6>
    <i class="fas fa-grin-beam" style="font-size:48px;color:red;float: none"></i>
    
    <!--The ad1.png and ad2.png are inserted -->
    <img src="images\ad1.png" alt="ads" align=left style="width:240px;height:415px">
    <img src="images\ad2.png" alt="ads" align=right style="width:240px;height:415px">
</div>  
<script>
    //This function enables user to sign in through their account if they have one.
function isUserRegistered(){
let Email=document.getElementById("formReg").txtEmail.value;
if(localStorage.getItem(Email)!=undefined)
{
    let user=JSON.parse(localStorage.getItem(Email));
    inputpassword=document.getElementById("formReg").txtPass1.value;
    if(user.pass1===inputpassword)
    {
        document.getElementById("signin").innerText="HELLO  "+user.UserName+" !";
        sessionStorage.loggedInUserName=user.email;
        localStorage.loggedInUserName=sessionStorage.loggedInUserName;
    }
    else
        document.getElementById("lblmsg").innerText="The password is incorrect!";
}
    else 
         document.getElementById("lblmsg").innerText="No such registered user exists!";
}
    
    //This function enables logged in user to sign out
function SignOut(){
        localStorage.removeItem('loggedInUserName');
    document.getElementById("lblmsg").innerText="You have succesfully logged out";
    }
</script>
<!--The login form is styled -->
<!--<p id="lblmsg" style="font-size:large;color:rgb(252, 80, 0);"></p>-->
<!--The login form is inserted-->
<form  id="formReg" onsubmit="return false;">
    
<!--The container class is called-->
<div class="container" style="margin-top:30px;">
    <!--Email label and input is inserted-->
    <label for="txtEmail" style="margin-left:30px;"><b>Email</b></label>
    <input type="text" class="input"placeholder="Enter Registered Email" name="txtEmail" required>
    
    <!--Password label and input is inserted-->
    <label for="txtPass1"style="margin-left:30px;margin-top:40px;"><b>Password</b></label>
    <input type="password" class="input" placeholder="Enter Password" name="txtPass1" required>
    
    <!--lgnbtn is inserted and styled-->
    <button onclick="isUserRegistered()" class="lgnbtn"style="background-color:limegreen;margin-left:20px;width:310px;">Play Now >></button>
    <button onclick="SignOut()" class="lgnbtn"style="background-color:red;margin-right:20px;width:310px;">Sign Out</button>
    
    <!--link for registering is inserted-->
    <p><a href="Register.php" style="background-color:transparent;color:red; margin-left:180px;">Dont have an account? Create one for free Now !</a>
    </p>
 </div>
</form><br>
<p id="lblmsg" style="font-size:30px;color:black;font-family:AR Darling;margin-left:400px"><b></b></p>
<?php
//outputFooter function is called,it displays the footer which is common to all pages
outputFooter();
?>