<?php
/*The outputHeader function contains the header common in all pages.It has the Relic Website logo and external stylesheet attached.It has the navigation bar with links to other pages of the website*/
function outputHeader(){
    echo'
<!DOCTYPE html>
<html>
<head>
<title>RelicGames</title>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">

 </head>
<body>   
<img src="images\relicgames.png" alt="RelicGames" style="width:1263px;height:330px;">
<div class="nav"> 
<div class="btn-group">
  <button class="button" style="vertical-align:middle"><span><a href="Login.php" style="background-color:black;">Login</a></span></button>
  <button class="button" style="vertical-align:middle"><span><a href="Register.php" style="background-color:black;">Register</a></span></button>
  <button class="button" style="vertical-align:middle"><span><a href="Highscores.php" style="background-color:black;">Highscores</a></span></button>
  <button class="button" style="vertical-align:middle"><span><a href="Home.php" style="background-color:black;">Home</a></span></button>
</div>
</div>

';}
?>
<?php
/*The outputFooter function contains the footer common in all pages.It has the links to terms of use,privacy policy,help and contact us. It has social media icons like twitter,facebook and goole */
function outputFooter(){
    echo'
<footer >
    <a href="#">TERMS OF USE |</a>
    <a href="#">PRIVACY POLICY |</a>
    <a href="#">CONTACT US |</a>
    <a href="#">HELP |</a>
<div class="icon" style="display:inline-block;float:right">
     <i class="fab fa-facebook-square"style="font-size:28px;color:lightblue;"></i>
     <i class="fab fa-google-plus-square"style="font-size:28px;color:orangered;"></i>
     <i class="fab fa-twitter-square"style="font-size:28px;color:aqua;"></i>
</div>
</footer>
</body>
</html>';
}
    ?>