<?php
//Including Common php as it contains the header,navigation and footer which is common for all the pages
include('common.php');
//outputHeader function is called,it displays the Header which is common to all pages
outputHeader();

?>
<!--The heading of the register page is styled-->
<h5><b>CREATE AN ACCOUNT NOW!</b></h5>

<!--Register.png Image for the page is inserted and styled-->
<img src="images\register.png" alt="Register" align=right style="width:350px;height:708px">
<script>
    
//    This function helps to save the user Details 
    function saveData()
    {
let user={
    
    UserName: document.getElementById("formReg").txtName.value,
    pass1: document.getElementById("formReg").txtPass1.value,
    email: document.getElementById("formReg").txtEmail.value,
    dateofbirth: document.getElementById("formReg").txtDate.value,
    score:0,
};
localStorage.setItem(user.email,JSON.stringify(user));
document.getElementById("lblmsg").innerText="---Congratulations! You have been Successfully Registered!----";
return false;
}
    //This function enables the user to delete their account when password is correct
    function unRegister()
{
let email=document.getElementById("formReg").txtEmail.value;
if(localStorage.getItem(email)!=undefined)
{
    let passEntered=document.getElementById("formReg").txtPass1.value;

    let user=JSON.parse(localStorage.getItem(email))

    if(passEntered==user.pass1)

    {localStorage.removeItem(email);
    document.getElementById("lblmsg").innerText="The user is deleted!";
    }

    else
   document.getElementById("lblmsg").innerText="The user cannot be removed; wrong password!";
}
else
document.getElementById("lblmsg").innerText="No such user exists!";
    
    //This function enables user to clear the local storage
}
    function clearData()
{
localStorage.clear();
document.getElementById("lblmsg").innerText=" ";
}
    
    //This function enables user to validate their password and know if they match
function validatePassword()
{
        pass1=document.getElementById("formReg").txtPass1.value;
        pass2=document.getElementById("formReg").txtPass2.value;

        if(pass1!=pass2)
        {
            document.getElementById("lblmsg").innerText="The passwords do not match!";
            document.getElementById("Register").disabled= true;
        }
        else
           
            document.getElementById("Register").disabled= false;
    }
    
    //This function enables user to proceed with the register only when all fields are filled
    function validateIsEmpty()
    {
        nameField=document.getElementById("formReg").txtName.value;
        emailField=document.getElementById("formReg").txtEmail.value;
        dateField=document.getElementById("formReg").txtDate.value;
       
        if ((nameField=="")||(emailField=="")||(dateField=="")){
            document.getElementById("lblmsg").innerText="Please ensure all fields are filled.";
           document.getElementById("Register").disabled= true;
        }
        else{
            document.getElementById("lblmsg").innerText="You have successfully filled the form.You can now register yourself.";
            document.getElementById("Register").disabled= false;
        }
        
    }
</script>
<!--Register form is inserted-->
<form id="formReg" onsubmit="return false;" style="border:1px solid #ccc">
    
<!--The container class is called-->
<div class="container">
    <!--Email label and input is inserted-->
    <label for="txtEmail"><b>Email ID</b></label>
    <input type="text" placeholder="Enter Email" name="txtEmail" required>
    
    <!--Date of birth label and input is inserted-->
    <label for="txtDate"><b>Date of birth</b></label>
    <input type ="text" placeholder="Date-Month-Year"  name="txtDate" required>
    <br>
    <!--Username label and input is inserted-->
    <label for="txtName"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="txtName" required>
    
    <!--Password labels and inputs is inserted-->
    <label for="txtPass1"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="txtPass1" required>
    
     <label for="txtPass2"><b>Confirm Password</b></label>
    <input type="password" placeholder="Re-type Password" name="txtPass2" required onchange="validatePassword()">
   
<!--The conditional statement for page is written and 'Terms and privacy' link is inserted -->
<p style="color:black">By creating an account you agree to our <a href="#" style="color:darkblue;background-color: transparent">Terms      & Privacy</a>.</p>

<!--The clearfix class is called which contains the buttons-->
    <div style="margin-bottom:100px;"class="clearfix">
    <button style="height:40px;width:250px;background-color:purple;"class="signupbtn" onclick="validateIsEmpty()">Check</button>
    <input style="height:40px;width:260px;background-color:purple;"type="button"class="signupbtn" onclick="unRegister()" value="Delete User">
    <input style="height:40px;width:255px;background-color:purple;"type="button" class="signupbtn"onclick="clearData()" value="Clear">
    <button style="height:40px;width:390px;background-color:limegreen;"class="signupbtn" id="Register" onclick="saveData()">Register >></button>
    <input style="height:40px;width:380px;background-color:red;"type="reset"class="signupbtn" value="Cancel">
    </div>
</div>
</form>  <br>
<p id="lblmsg" style="font-size:30px;color:black;font-family:AR Darling;margin-left:50px"><b></b></p>

<?php
//outputFooter function is called,it displays the footer which is common to all pages
outputFooter();
?>