<?php
//Including Common php as it contains the header,navigation and footer which is common for all the pages
include('common.php');
//outputHeader function is called,it displays the Header which is common to all pages
outputHeader();
?>
<!--The styling for the images and heading is done along with the icons-->
<div class="imges">
    <!--The trophy icons for the page is inserted inline-block and styled with the HIGHSCORES text-->
    <i class="fa fa-trophy" style="font-size:48px;color:green;display:inline-block;margin-left:170px;"></i>
    <h4 ><b>HIGHSCORES</b></h4>
    <i class="fa fa-trophy" style="font-size:48px;color:green;float: none;"></i>
    
    <!--The Highscore.png images in the Highscore page is styled-->
    <img style="height:900px;"src="images\Highscore.png" alt="Leaderboard" align=left>
    <img  style="height:900px"src="images\Highscore.png" alt="Leaderboard" align=right>
</div>
<script>
    //This function enables the user scores to display in the highscore table
    window.onload=function listScores(){
        for (let [key, value] of Object.entries(localStorage)) {
            if(key!="loggedInUserName"){
        var userscore=JSON.parse(localStorage.getItem(key));
         document.getElementById("highscorelist").innerHTML+= "<div class= sample><p style=margin-left:220px;font-family:cursive;font-size:30px;>"+userscore.UserName+"&emsp; &emsp; &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;"+userscore.score+"</p></div>";
         }  
        }    
      }
</script>

<!--The sample class is called for displaying contents of HIGHSCORES-->
    <div style="background-color:purple;"class="sample"><p style="margin-left:200px;font-size:35px;font-family:AR Darling">USER &emsp; &emsp; &emsp; &emsp;&emsp;&emsp;SCORE</p></div>
    <div style="margin-bottom:416px;"id="highscorelist"></div>
<?php
//outputFooter function is called,it displays the footer which is common to all pages
outputFooter();
?>
