<?php
//Including Common php as it contains the header,navigation and footer which is common for all the pages
include('common.php');
//outputHeader function is called,it displays the Header which is common to all pages
outputHeader();
?>
<!--/*Kung fu adventure is the name of the game*/-->
<h1 ><b>KUNG FU ADVENTURE</b></h1>
<!----finalgame.png is the image of the game and it has the play button which takes you to the game page-->
<img src="images\finalgame.png" alt="KungFuGame"style="width:1000px;height:510px;margin-left:120px;">
<a href="Game.html"><img src="images\BUTTON.png"  style="margin-top:-250px;margin-bottom:43px;margin-left:795px;width:300px;height:200px;"></a>
<!--This home content class contains the instructions and description of the game -->
<article class="browser">
<div class="home content">
    <h2><b>HOW TO PLAY</b> </h2>
    <P><b>Help Po-the Kung Fu Warrior in his journey home by saving it from the evil Warrior Tai Lung! Help him jump over sharp objects and at the same time, collect chi and feed Po his favorite dumplings!. Po’s journey is endless so travel as far as possible to achieve the highest score!</b></P>
    
    <P><b><br>Use the JUMP button to control Po. Collecting dumplings earn 20 extra points. Collecting chi earns 30 extra points on the other hand touching an obstacle ends the game. Make sure you achieve the highest score to get your name displayed at the top of the ranks!</b></P>
</div>
<!--In this walkthrough video class is called-->
<div class="walkthrough video">
   <h3><b>WALKTHROUGH</b> </h3>
</div>
    
<!--The walkthrough video is inserted and styled-->

<video style="width:500px;height:250px;margin-right: 40px;margin-bottom:50px;" controls><source src="images\GameWalkthrough.mp4" type="video/mp4"></video>
</article>
<?php
//outputFooter function is called,it displays the footer which is common to all pages
outputFooter();
?>